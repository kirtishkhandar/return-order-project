package com.returnordermanagementsystem.componentprocessing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComponentProcessingApplicationTests {

	@Test
	void contextLoads() {
	}

}
