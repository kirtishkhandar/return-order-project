package com.returnordermanagementsystem.packaginganddeliverymodule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PackagingAndDeliveryModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
